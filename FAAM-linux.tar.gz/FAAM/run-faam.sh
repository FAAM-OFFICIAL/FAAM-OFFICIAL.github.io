#!/usr/bin/env bash
# FAAM for Linux — runs the local server and opens FAAM in your browser.
set -e
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install it with your package manager, e.g.:"
  echo "  Debian/Ubuntu:  sudo apt install python3"
  echo "  Fedora:         sudo dnf install python3"
  echo "  Arch:           sudo pacman -S python"
  exit 1
fi
# OpenAI key (optional): from the environment, a previous run, or a prompt.
if [ -z "$OPENAI_API_KEY" ] && [ -f "$HOME/.faam/key" ]; then
  OPENAI_API_KEY="$(cat "$HOME/.faam/key")"; export OPENAI_API_KEY
fi
if [ -z "$OPENAI_API_KEY" ]; then
  printf 'Paste your OpenAI API key (sk-...), or press Enter to skip: '
  read -r KEY
  if [ -n "$KEY" ]; then
    mkdir -p "$HOME/.faam"; printf '%s' "$KEY" > "$HOME/.faam/key"
    chmod 600 "$HOME/.faam/key"; export OPENAI_API_KEY="$KEY"
  fi
fi
PORT="${FAAM_PORT:-8765}"; export FAAM_PORT="$PORT"
URL="http://localhost:$PORT/login"
# Open the browser once the server answers, in the background.
( for _ in $(seq 1 40); do
    if command -v curl >/dev/null 2>&1; then
      curl -fsS "http://localhost:$PORT/api/health" >/dev/null 2>&1 && break
    elif command -v wget >/dev/null 2>&1; then
      wget -qO- "http://localhost:$PORT/api/health" >/dev/null 2>&1 && break
    else
      sleep 1.5; break
    fi
    sleep 0.4
  done
  (xdg-open "$URL" >/dev/null 2>&1 || sensible-browser "$URL" >/dev/null 2>&1 \
    || x-www-browser "$URL" >/dev/null 2>&1 || true) ) &
echo "Starting FAAM at $URL   (press Ctrl+C to stop)"
exec python3 app.py
